if ([System.Environment]::OSVersion.Version -lt "6.2.9200.0") { Throw "The minimum OS requirement was not met."}

Import-Module RemoteDesktop

$localhost = [System.Net.Dns]::GetHostByName((hostname)).HostName


#######################################################################
# The Get-TargetResource cmdlet.
#######################################################################
function Get-TargetResource
{
    [CmdletBinding()]
    [OutputType([System.Collections.Hashtable])]
    param
    (    
        [string] $ConnectionBroker,
 
        [parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string] $CollectionName
    )

    $result = $null

    if ($ConnectionBroker)
    {
        write-verbose "Getting information about RD Session collection '$CollectionName' at RD Connection Broker '$ConnectionBroker'..."
     
        $collection = Get-RDSessionCollection -CollectionName $CollectionName -ConnectionBroker $ConnectionBroker -ea SilentlyContinue
    }
    else
    {
        write-verbose "Getting information about RD Session collection '$CollectionName'..."
     
        $collection = Get-RDSessionCollection -CollectionName $CollectionName -ea SilentlyContinue

        $ConnectionBroker = $localhost
    }

    if ($collection)
    {
        write-verbose "found the collection, now getting list of RD Session Host servers..."

        $SessionHosts = Get-RDSessionHost -CollectionName $CollectionName | % SessionHost
        write-verbose "found $($SessionHosts.Count) host servers assigned to the collection."
        
        #loop
        $SessionHosts | ForEach-Object {
            if ($_ -ieq $localhost){
                $result = 
                @{
                    "ConnectionBroker" = $ConnectionBroker
                
                    "CollectionName"   = $collection.CollectionName
                    "CollectionDescription" = $collection.CollectionDescription

                    "SessionHosts" = $SessionHosts
                }

                write-verbose ">> Collection name:  $($result.CollectionName)"
                write-verbose ">> Collection description:  $($result.CollectionDescription)"
                write-verbose ">> RD Connection Broker:  $($result.ConnectionBroker.ToLower())"
                write-verbose ">> RD Session Host servers:  $($result.SessionHosts.ToLower() -join '; ')"
            }
        }
    }
    else
    {
        write-verbose "RD Session collection '$CollectionName' not found."
    }

    $result
}


######################################################################## 
# The Set-TargetResource cmdlet.
########################################################################
function Set-TargetResource
{
    [CmdletBinding()]
    param
    (    
        [string] $ConnectionBroker,
        
        [parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string] $CollectionName
    )

    if ($ConnectionBroker)
    { 
        write-verbose "Editing RD Session collection '$CollectionName' at the RD Connection Broker '$ConnectionBroker'..."
    }
    else
    {
        $PSBoundParameters.Remove("ConnectionBroker")
        write-verbose "Editing RD Session collection '$CollectionName'... from local machine"
    }

    $collectionExists = $false
    $collections = Get-RDSessionCollection | % CollectionName
    $collections | ForEach-Object {
            if ($_ -ieq $CollectionName){
                $collectionExists = $true
            }
    }

    if ($collectionExists){
        write-verbose "Simply adding local server to RD Session collection '$CollectionName'"
        Add-RDSessionHost @PSBoundParameters -SessionHost $localhost
    }
    else {
        write-verbose "calling New-RdSessionCollection cmdlet..."
        New-RDSessionCollection @PSBoundParameters -SessionHost $localhost
    }
    

    #    Add-RDSessionHost @PSBoundParameters  # that's if the Session host is not in the collection
}


#######################################################################
# The Test-TargetResource cmdlet.
#######################################################################
function Test-TargetResource
{
    [CmdletBinding()]
    [OutputType([System.Boolean])]
    param
    (
        [string] $ConnectionBroker,

        [parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string] $CollectionName
    )

    write-verbose "Checking for existence of current session host in RD Session collection named '$CollectionName'..."
    
    $collection = Get-TargetResource @PSBoundParameters
    
    if ($collection)
    {
        write-verbose "verifying RD Session collection name and parameters..."
        $result =  ($collection.CollectionName -ieq $CollectionName)
    }
    else
    {
        write-verbose "RD Session collection named '$CollectionName' not found."
        $result = $false
    }

    write-verbose "Test-TargetResource returning:  $result"
    return $result
}


Export-ModuleMember -Function *-TargetResource